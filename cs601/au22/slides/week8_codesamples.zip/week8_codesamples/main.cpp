#include<iostream>
#include<cstdlib>
#include"myvec.h"
using namespace std;
int main() {
	MyVec v(10); //calls the constructor MyVec::MyVec(int) and passes the argument 10
	int size=v.GetVecLen(); //calls the member function
	cout<<"v's size: "<<size<<" elements"<<endl;
	cout<<"Setting v's first element to 100"<<endl;
	v[0]=100;
	cout<<"Fetching v's first element: "<< v[0] << endl;
	MyVec v2(10), v3(10);
	v2=v3=v;
	cout<<"Fetching v2's and v3's first elements after assignment v2=v3=v: "<< v2[0] <<" "<<v3[0]<< endl;
	
	cout<<"Setting v's first element to 200"<<endl;
	v[0]=200;
	(v2=v3)=v;
	cout<<"Fetching v2's and v3's first elements after assignment (v2=v3)=v: "<< v2[0] <<" "<<v3[0]<< endl;

	cout<<"Performing v+1000.. "<< endl;
	v = v+1000;
	cout<<"Fetching first element value: "<< v[0] << endl;
}
