//A short program to illustrate the usage of reference variables.
#include<stdio.h>
int main(){
	int x=10;
	int &y=x;
	int z=20;
	int &w=z; //once initialized always binds to z's memory location 
	y=w; //content's from w's memory location are copied and written into y's memory location (i.e. memory location of x).
	printf("x=%d\n",x);
}
