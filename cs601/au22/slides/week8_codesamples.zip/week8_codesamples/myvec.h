#ifndef MYVEC_H
#define MYVEC_H
class MyVec{
	//private attributes
	double* data;
	int vecLen;
public:
	MyVec(int len); //constructor decl.
	MyVec(const MyVec& rhs); //copy constructor
	int GetVecLen() const; //member function
	double& operator[](int index) const;
	MyVec& operator=(const MyVec& rhs);
	MyVec& operator+=(double val);
	MyVec operator+(const MyVec& vec2);
	//const MyVec operator+(double val);
	~MyVec(); //destructor decl.


};

#endif
