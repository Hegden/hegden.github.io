#include"myvec.h"
//defining the constructor
MyVec::MyVec(int len) {
	vecLen=len;
	data=new double[vecLen];
}

MyVec::MyVec(const MyVec& rhs) {
	vecLen=rhs.GetVecLen();
	data=new double[vecLen];
	for(int i=0;i<vecLen;i++) {
		data[i] = rhs[i];
	}
}

//defining GetVecLen member function
int MyVec::GetVecLen() const {
	return vecLen;
}

double& MyVec::operator[](int index) const {
	return data[index];
}

MyVec& MyVec::operator=(const MyVec& rhs) {
	vecLen=rhs.GetVecLen();
	for(int i=0;i<vecLen;i++) {
		data[i] = rhs[i];
	}
	return *this;
}

MyVec& MyVec::operator+=(double val) {
	for(int i=0;i<vecLen;i++)
		data[i] += val;
	return *this;
}

MyVec MyVec::operator+(const MyVec& vec2) {
	//assumption: vec2 is of the same length as vec1
	for(int i=0;i<vecLen;i++)
		(*this).data[i] += vec2.data[i];
	return *this;
}

/*const MyVec MyVec::operator+(double val) {
	//assumption: vec2 is of the same length as vec1
	for(int i=0;i<vecLen;i++)
		data[i] += val;
	return *this;
}*/

//defining the destructor
MyVec::~MyVec() {
	delete [] data;
}








