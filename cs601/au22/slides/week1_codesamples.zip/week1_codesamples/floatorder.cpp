//CS601: code to show that floating point arithmetic is not associative. Example borrowed from Matrix Computations, Golub and Van Loan.
#include<iostream>
#include<iomanip>
#include<cmath>
using namespace std;
int main(int argc, char* agv[]) {
	double a=1.24*pow(10,0), b=-1.23*pow(10,0), c=1.00*pow(10,-3);
	cout<<"(a+b)+c = "<<setprecision(15)<<(a+b)+c<<endl;
	cout<<"a+(b+c) = "<<setprecision(15)<<a+(b+c)<<endl;
}
