//CS601: code to show catastrophic cancellation. Example borrowed from Matrix Computations, Golub and Van Loan.
#include<iostream>
#include<iomanip>
#include<cmath>
using namespace std;
int main(int argc, char* agv[]) {
	//compute the smaller of the roots of x^2 - 2px - q=0, given p=12345678 and q=1
	int p=12345678, q=1;
	double root;
	//Method 1: using the formula -b-sqrt((b^2-4*a*c))/2*a : p - sqrt(p^2+q) 
	root=p - sqrt(pow(p,2)+q);
	cout<<"Method 1: p - sqrt(p^2 + q) = "<<setprecision(15)<<root<<endl;
	//Method 2: using the formula 2c/(-b+sqrt(b^2-4*a*c))
	root= - q / (p+sqrt(pow(p,2)+q));
	cout<<"Method 2: - q / (p+sqrt(p^2+q)) = "<<setprecision(15)<<root<<endl;
}
