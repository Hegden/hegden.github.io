#include<iostream>
#include"myvec.h"
using namespace std;
int main() {
	MyVec v(10); //calls the constructor MyVec::MyVec(int) and passes the argument 10
	int size=v.GetVecLen(); //calls the member function
	cout<<"size of MyVec is: "<<size<<" elements"<<endl;
	cout<<"Setting first element to 100"<<endl;
	v[0]=100;
	cout<<"Fetching first element value: "<< v[0] << endl;
	MyVec v2=v; //calls the copy constructor
	cout<<"v2's first element: "<<v2[0]<<endl;
}
