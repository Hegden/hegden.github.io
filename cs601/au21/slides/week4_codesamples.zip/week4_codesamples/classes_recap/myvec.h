#ifndef MYVEC_H
#define MYVEC_H
class MyVec{
	//private attributes
	double* data;
	int vecLen;
public:
	MyVec(int len); //constructor decl.
	MyVec(const MyVec& rhs); //copy constructor
	int GetVecLen() const; //member function
	double& operator[](int index) const;
	~MyVec(); //destructor decl.


};

#endif
