#ifndef SCPROD_V2_H
#define SCPROD_V2_H
//#pragma once
namespace cs601{
template<typename T>
T ddot(int dim, T* vec1, T* vec2);
}

#include "../src/scprod_v2.cpp"

#endif
