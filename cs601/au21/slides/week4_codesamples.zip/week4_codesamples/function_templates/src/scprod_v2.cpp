template<typename T>
T cs601::ddot(int dim, T* vec1, T* vec2) {
	T result=0.;
	for(int i=0;i<dim;i++) {
		result += (vec1[i] * vec2[i]);
	}
	return result;
}
