#include<stdio.h>

/*Function that returns the result of the expression (a+1)*(b+2)+(a+1)+(b+2)*/
int foo(int a, int b) {
	int x = a+1;
	int y = b+2;
	int sum=x+y;

	return x*y+sum;
}

int main(int argc, char* argv[]) {
	int ret = foo(9, 18); //compute expression
	printf("Value returned from foo: %d\n",ret); //print result
	return 0;
}
