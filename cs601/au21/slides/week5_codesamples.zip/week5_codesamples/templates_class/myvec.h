#ifndef MYVEC_H
#define MYVEC_H
template<typename T>
class MyVec{
	//private attributes
	T* data;
	int vecLen;
public:
	MyVec(int len); //constructor decl.
	MyVec(const MyVec& rhs); //copy constructor
	int GetVecLen() const; //member function
	T& operator[](int index) const;
	~MyVec(); //destructor decl.
};

//defining the constructor
template<typename T>
MyVec<T>::MyVec(int len) {
	vecLen=len;
	data=new T[vecLen];
}

template<typename T>
MyVec<T>::MyVec(const MyVec<T>& rhs) {
	vecLen=rhs.GetVecLen();
	data=new T[vecLen];
	for(int i=0;i<vecLen;i++) {
		data[i] = rhs[i];
	}
}

//defining GetVecLen member function
template<typename T>
int MyVec<T>::GetVecLen() const {
	return vecLen;
}

template<typename T>
T& MyVec<T>::operator[](int index) const {
	return data[index];
}

//defining the destructor
template<typename T>
MyVec<T>::~MyVec() {
	delete [] data;
}
#endif
