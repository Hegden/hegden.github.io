#include<iostream>
int main(){
  char* str="Hello";
  char* p=str;
  p[0]='Y';
  std::cout<<str;
}
