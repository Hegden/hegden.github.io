#include<stdio.h>
#include<cstdlib>
#include<sys/time.h>


#ifdef PAPI
#include"papi.h"
inline void handle_error(int retval)
{
	printf("PAPI error %d: %s\n",retval, PAPI_strerror(retval));
	exit(1);
}
#endif

int main(int argc, char* argv[]){
	if(argc != 2) {
		printf("Usage: ./matvec N\n");
		exit(0);
	}

#ifdef PAPI
	int retval, EventSet=PAPI_NULL;
	long long values[4] = {(long long)0, (long long)0, (long long)0, (long long)0};
	//long long values[2] = {(long long)0, (long long)0};

	retval = PAPI_library_init(PAPI_VER_CURRENT);
	if(retval != PAPI_VER_CURRENT)
		handle_error(retval);
	
	retval = PAPI_create_eventset(&EventSet);
	if (retval != PAPI_OK) 
		handle_error(retval);
 
	// Add event L1 Total Cache Misses 
	retval = PAPI_add_event(EventSet, PAPI_L1_TCM);
	if (retval != PAPI_OK) 
		handle_error(retval);
	
	// Add event L2 Total Cache Misses 
	retval = PAPI_add_event(EventSet, PAPI_L2_TCM);
	if (retval != PAPI_OK) 
		handle_error(retval);

	// TOTAL cycles 
	retval = PAPI_add_event(EventSet, PAPI_TOT_CYC);
	if (retval != PAPI_OK) 
		handle_error(retval);
	
	// TOTAL instructions 
	retval = PAPI_add_event(EventSet, PAPI_TOT_INS);
	if (retval != PAPI_OK) 
		handle_error(retval);
#endif
	int n= atoi(argv[1]);
	double** A=new double*[n];
	for(int i=0;i<n;i++)
		A[i]=new double[n];

	double* x=new double[n];
	double* y=new double[n];
	
	int ctr=1;
	for(int i=0;i<n;i++)
		for(int j=0;j<n;j++)
			A[i][j]=ctr++;

	for(int i=0;i<n;i++) {
		x[i]=1;
		y[i]=0;
	}
	
	struct timeval tv_before, tv_after;
// row-wise
        gettimeofday(&tv_before, NULL);
	
#ifdef PAPI
	retval = PAPI_start(EventSet);
	if (retval != PAPI_OK) handle_error(retval);
#endif

 	for (int i = 0; i < n; i++)
 		for (int j = 0; j < n; j++)
			y[i] += A[i][j]*x[j];
	
#ifdef PAPI
	retval = PAPI_stop(EventSet, values);
	if (retval != PAPI_OK) handle_error(retval);
#endif
        
	gettimeofday(&tv_after, NULL);
	printf("Row-wise time(n=%d): %ld (us)\n",n,((tv_after.tv_sec - tv_before.tv_sec)*1000000L + tv_after.tv_usec) - tv_before.tv_usec);


#ifdef PAPI
	float ratio = values[0]/(float)(values[1]);
	printf("total L1 misses:%lld total L2 misses:%lld total instructions:%lld total cycles:%lld\n", values[0],values[1], values[3], values[2]);
#endif

	delete [] x;
	delete [] y;
	for(int i=0;i<n;i++)
		delete [] A[i];
	delete [] A;
}
