#include<iostream>
#include<cstdlib>
#include<sys/time.h>

int main(int argc, char* argv[]){
	if(argc != 2) {
		std::cout<<"Usage: ./matmul N"<<std::endl;
		exit(0);
	}
	int n= atoi(argv[1]);
	double** A=new double*[n];
	for(int i=0;i<n;i++)
		A[i]=new double[n];

	double* x=new double[n];
	double* y=new double[n];
	
	int ctr=1;
	for(int i=0;i<n;i++)
		for(int j=0;j<n;j++)
			A[i][j]=ctr++;

	for(int i=0;i<n;i++) {
		x[i]=1;
		y[i]=0;
	}
	
	struct timeval tv_before, tv_after;
	uint64_t ret;
// row-wise
        gettimeofday(&tv_before, NULL);
 	for (int i = 0; i < n; i++)
 		for (int j = 0; j < n; j++)
			y[i] += A[i][j]*x[j];
        gettimeofday(&tv_after, NULL);
	std::cout<<"Rowwise time n="<<n<<" (us): "<<((tv_after.tv_sec - tv_before.tv_sec)*1000000L + tv_after.tv_usec) - tv_before.tv_usec<<std::endl;
// col-wise
        gettimeofday(&tv_before, NULL);
	 for (int j = 0; j < n; j++)
 		for (int i = 0; i < n; i++)
			y[i] += A[i][j]*x[j];
        gettimeofday(&tv_after, NULL);
	std::cout<<"Colwise time n="<<n<<" (us): "<<((tv_after.tv_sec - tv_before.tv_sec)*1000000L + tv_after.tv_usec) - tv_before.tv_usec<<std::endl;

	delete [] x;
	delete [] y;
	for(int i=0;i<n;i++)
		delete [] A[i];
	delete [] A;
}
