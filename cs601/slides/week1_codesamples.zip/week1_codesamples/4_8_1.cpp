//code to compute the root of x-cosx
#include<stdio.h>
#include<iostream>
#include<iomanip>
#include<cmath>
using namespace std;
int main(int argc, char* agv[]) {
	
	double x_n, x_np1;
	cout<<"enter value of initial guess"<<endl;
	cin >> x_n;
	int maxIterations=10000, iteration=0;
	double tolerance = 1e-12, error;
	error=tolerance+1;
	while((error >= tolerance) && (iteration<maxIterations)) {
		x_np1 = x_n - (x_n - cos(x_n))/(1+sin(x_n));		
		cout<<"x_np1 "<<setprecision(12)<<x_np1<<endl;
		error=fabs(x_np1-x_n);
		x_n = x_np1;
		iteration = iteration + 1;
	}
	
	if(error <= tolerance)
		cout<<"root is "<<setprecision(15)<<x_n<<endl;
	else	
		cout<<"Did not converge."<<endl;
}
