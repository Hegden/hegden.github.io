//CS601: Code used to demonstrate the usage of gdb, gprof, and valgrind. Example drawn from serc.iisc.ac.in (Param Pravega Users' Manual)
#include<stdio.h>
#include<stdlib.h> //for malloc, rand, srand
#include<unistd.h> //getpid
#define N 100
#define N_LEN 100
short generate_randshort(){
	short sum=1;
	for(short i=0;i<(rand() % N);++i) {
		for(short j=0;i<N;++j) {
			int val=(i*j)/(i+j);
			sum += (val!=0)?val:sum; 	
		}
	}
	return sum;
}

long long fact(unsigned int x){
	if(x==1 || x==0)
		return 1LL;
	else
		return x*fact(x-1);
}

int main(int argc, char* argv[]){
	short f1=0;
	//provide a seed to srand based on process id
	srand((unsigned int)getpid());
	//generate a random number
	f1=generate_randshort() % 10;
	//get the factorial
	long long factrandom=fact(f1);
	//normalize
	int factnormalized=factrandom % (N_LEN+1);
	//create an array of above size.
	int * arr=new int[factnormalized];
	if(arr == NULL){
		printf("Not enough memory\n");
		return EXIT_FAILURE;
	}
	//populate the array
	for(int  i=0;i<factnormalized;i++) //TODO: modify code while illustrating the use of gprof.
		arr[i]=factnormalized-i;
	//print
	for(int i=factnormalized-1;i>=0;--i)
		printf("%0d", (arr[i]+rand())%10);
	for(int i=(N_LEN-factnormalized);i>=0;--i)
		printf("%0d", rand()%10);

	//TODO: fill code while ilustrating the usage of valgrind.
	return EXIT_SUCCESS;
}
