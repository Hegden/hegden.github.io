#ifndef SCPROD_H
#define SCPROD_H
//Note that the template definition is included in this (header) file itself!
//this is the usual coding practice for templates. Some define the template definition
//in a separate .cpp file and include the .cpp file where needed.
namespace cs601{
template<typename T>
T scprod(int dim, T* vec1, T* vec2) {
	T result=0.;
	for(int i=0;i<dim;i++) {
		result += (vec1[i] * vec2[i]);
	}
	return result;
}
}

#endif
