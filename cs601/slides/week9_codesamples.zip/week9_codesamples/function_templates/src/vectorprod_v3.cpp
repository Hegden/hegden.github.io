//file used in demo (inclusion of template definition done in the scprod_v3.cpp in the scprod_v3.h header file. Other files used in this demo are scprod_v3.cpp, scprod_v3.h, and makefile_v3. Note that even though scprod_v3.cpp is named as a .cpp file, it is not compiled. Look at the makefile_v3.)
#include<sstream>
#include<iostream>
#include"scprod_v3.h"
using namespace std;
int main(int argc, char* argv[]) {
	int dim;
	//if the vector dimension is not supplied through command-line arguments then accept it from keyboard.
	
	/*atoi returns 0 in case of invalid numbers entered as well as when a 0 is entered. 
	* Hence, to differentiate between the two scenarios and provide meaningful feedback to the
	* user, we use stringstreams. */

	if(argc != 2){
		cout << "Enter the vector dimension"<<endl;
		string dimstr;
		cin>>dimstr;
		istringstream ss;
		ss.str(dimstr);
		if(!(ss>>dim)) {
			cerr<<"Invalid number: "<<dimstr<<endl;
			return EXIT_FAILURE;
		} else if(!(ss.eof())) {
			cerr<<"Trailing characters present after the number: "<<dimstr<<endl;
			return EXIT_FAILURE;
		} 
		//cin >> dim;
	}
	else {
		istringstream ss(argv[1]);
		if(!(ss>>dim)) {
			cerr<<"Invalid number: "<<argv[1]<<endl;
			return EXIT_FAILURE;
		} else if(!(ss.eof())) {
			cerr<<"Trailing characters present after the number: "<<argv[1]<<endl;
			return EXIT_FAILURE;
		}
	}

	cout << "Value of dimension entered: "<<dim<<endl;
	
	double* vector1, *vector2;
	//allocate memory for vectors
	vector1 = new double[dim];
	vector2 = new double[dim];

	//initialize vectors
	for(int i=0;i<dim;i++) {
		vector1[i] = 1.;
		vector2[i] = 1.;
	}

	//multiply vector of doubles and store the result in a new double
	double dResult=0.;
	dResult = cs601::scprod(dim, vector1, vector2);
	cout<<"Product of two vectors (double): "<<dResult<<endl;
	
	int* vector3, *vector4;
	//allocate memory for vectors
	vector3 = new int[dim];
	vector4 = new int[dim];

	//initialize vectors
	for(int i=0;i<dim;i++) {
		vector3[i] = i+1;
		vector4[i] = i+1;
	}
	int iResult=0.;
	//multiply vector of int and store the result in a new int
	iResult = cs601::scprod(dim, vector3, vector4);
	//print the product
	cout<<"Product of two vectors (int): "<<iResult<<endl;
	return 0;
}
