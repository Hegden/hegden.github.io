#include<iostream>
#include"myvec.h"
using namespace std;
int main() {
	/*creates a MyVec Object whose member 'data' has type double*.
	 * The 'data' field has storage reserved for 10 elements of type double */
	MyVec<double> v(10); 
	v[0]=3.141952;

	//creates a MyVec Object whose member 'data' has type int*
	MyVec<int> v2(10); 
	v2[0]=10000;

	cout<<v[0]<<" "<<v2[0]<<endl;

}
