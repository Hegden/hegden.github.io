#ifndef SCPROD_H
#define SCPROD_H
//#pragma once

int scprod(int dim, int vec1[], int vec2[]);

#endif
