#include<iostream>
int main(){
  float a[10];
  a[0]=0x12345678;
  unsigned char* bytestream = (unsigned char*)a; 
  printf("%x\n",bytestream[0]);
}
