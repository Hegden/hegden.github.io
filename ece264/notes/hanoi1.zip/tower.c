#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tower.h"

Tower * createTower(int maxsize, char * name) {
	Tower * retval = malloc(sizeof(Tower));
	retval->disks = malloc(sizeof(int) * maxsize);
	retval->maxdisks = maxsize;
	retval->curdisks = 0;
	retval->name = malloc(sizeof(char) * (strlen(name) + 1));
	strcpy(retval->name, name);
	return retval;
}

void freeTower(Tower * t) {
	free(t->disks);
	free(t->name);
	free(t);
}

void initTower(Tower * t, int numdisks) {
	t->curdisks = numdisks;
	for (int i = 0; i < numdisks; i++) {
		t->disks[i] = (numdisks - 1) - i;
	}
	return;
}

void printTower(Tower * t) {
	printf("Tower %s\n", t->name);
	printf("\t: ");
	for (int i = 0; i < t->curdisks; i++) {
		printf("%d ", t->disks[i]);
	}
	printf("\n");
}


void move(Tower * dest, Tower * src) {
	int disk = src->disks[--(src->curdisks)];
	dest->disks[dest->curdisks++] = disk;
	fprintf(stdout, "Moved disk %d from %s to %s\n", disk, src->name, dest->name);
	if ((dest->curdisks > 1) && (dest->disks[dest->curdisks - 1] >= dest->disks[dest->curdisks - 2])) {
		fprintf(stderr, "Illegal move from %s to %s!\n", src->name, dest->name);
		exit(1);
	}	
	
}