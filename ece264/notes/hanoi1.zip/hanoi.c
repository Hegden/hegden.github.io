#include <stdlib.h>
#include <stdio.h>
#include "tower.h"

Tower * t_a, * t_b, * t_c;

void printTowers() {
	printTower(t_a);
	printTower(t_b);
	printTower(t_c);
}

void hanoiRec(Tower * src, Tower * dest, Tower * temp, int toMove) {
	if (toMove == 0) {
		return;
	}
	
	hanoiRec(src, temp, dest, toMove - 1);
	
	move(dest, src);
	
	hanoiRec(temp, dest, src, toMove - 1);	
}


void hanoi(Tower * one, Tower * two, Tower * three) {
	hanoiRec(one, three, two, one->curdisks);
}

int main(int argc, char ** argv) {
	
	int maxdisks = 0;
	
	if (argc != 2) {
		fprintf(stderr, "Wrong number of arguments\n");
		fprintf(stderr, "Usage: ./hanoi <number of disks>\n");
		exit(1);
	} else {
		maxdisks = atoi(argv[1]);
	}
	
	t_a = createTower(maxdisks, "A");
	t_b = createTower(maxdisks, "B");
	t_c = createTower(maxdisks, "C");	
	initTower(t_a, maxdisks);
	
	printTowers();
	
	hanoi(t_a, t_b, t_c);

	printTowers();
	
	freeTower(t_a);
	freeTower(t_b);
	freeTower(t_c);
	
	return 0;
}