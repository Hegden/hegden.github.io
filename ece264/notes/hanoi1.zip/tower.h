#ifndef _TOWER_H_
#define _TOWER_H_

typedef struct Tower {
	int * disks;
	int maxdisks;
	int curdisks;
	char * name;
} Tower;

Tower * createTower(int maxsize, char * name);

void freeTower(Tower * t);

void initTower(Tower * t, int numdisks);

void printTower(Tower * t);

void move(Tower * dest, Tower * src);

#endif