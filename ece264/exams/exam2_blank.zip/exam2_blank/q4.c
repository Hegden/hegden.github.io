/* This question has FIVE  sub-questions. Please answer all of them. 
 * This question tests your understanding of linked lists: How you can create a list and traverse it*/

#include <stdio.h>
#include <stdlib.h>

/*creates a Node type in a linked list*/
typedef struct Node {
struct Node* nxt;
int val;
}Node;

/*This function inserts a new node at the beginning of the list. when this function returns, (*loc) points to the new node created*/
void insert(Node** loc, int value) {

/*Q4.A (2 points) create a node in a linked list.*/
Node* newNode = /*your answer here.*/
newNode->val = value; 

/*Q4.B (2 points) initialize 'nxt' member of the node created */
newNode->nxt =  /*your answer here*/

/*Q4.C (2 points) your code for computing insert function's output here*/

}

void printList(Node* head) {
	Node* curr = head;
	while(curr != NULL) {
		printf("%d", curr->val);
		if(curr->nxt != NULL) {
			printf(" -> ");
		}
		curr = curr->nxt;
	}
	printf("\n");
}

/* Q4.E (15 points) printList function defined above prints the list using a while loop.
 * Fill printList2 to print the list using a for loop. */ 
void printList2(Node* head) {
	for(/*your answer here*/) {
		printf("%d", cur->val);
		if(cur->nxt != NULL) {
			printf(" -> ");
		}
	}
	printf("\n");
}

int main(int argc, char* argv[]) {
	Node* head = NULL; 
	/*Q4.D (4 points): call insert 4 times to create 4 nodes. At the end of the 4 calls, printList should print 10 -> 20 -> 30 -> 40. */
	/*your answer here*/
 
	printList(head);
	/*printList2 should print the same output as printList*/
	printList2(head); 
	/*freeing memory */
	Node* tmp=head;
	while(tmp!=NULL) {
		Node* nextNode = tmp->nxt;
		free(tmp);
		tmp=nextNode;
	}
}
