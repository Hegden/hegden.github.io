/* This question has THREE sub-questions. Please answer all of them.
 * This question tests your understanding of recursive codes, and how you can analyze such codes.*/

#include <stdio.h>
#include <stdlib.h>

int f1(int a)
{
  if (a <= 0)
    {
      return 0;
    }
  int temp = f1(a - 1);
  temp += a;
  return temp;
}

int f2(int a)
{
  if (a <= 1)
    {
      return a;
    }
  int temp1 = f2(a - 1);
  int temp2 = f2(a - 2);
  int temp3 = temp1 + temp2;
  return temp3;
}

void f3(int i, int j, int k, int l)
{
	if(i == 0)
		return;
	f3(i-1,j,l,k);
	f3(i-1,l,k,j); 
	f3(i-1,k,l,j); 
}

int main(int argc, char ** argv)
{
  /*Q1.A What should be the value of inputF1 so that function f1 returns 55? (5 points)*/
  int inputF1=; /*write your answer here.*/
  int v1 = f1(inputF1);
  printf("v1=%d inputF1=%d\n", v1, inputF1); /* prints answer Q1.A*/

  /*Q1.B What should be the value of inputF2 so that function f2 returns 55? (5 points)
 * Hint: think of Fibonacci series.*/
  int inputF2=; /*write your answer here.*/
  int v2 = f2(inputF2);
  printf("v2=%d inputF2=%d\n", v2, inputF2); /* prints answer Q1.B*/

  /*Q1.C How many times function f3 is called in this recursive call? (10 points)*/
  int numCallsToF3=; /*write your answer here*/
  f3(3, 65, 66, 67);
  printf("%d\n",numCallsToF3); /*prints answer Q1.C*/
  return EXIT_SUCCESS;
}

