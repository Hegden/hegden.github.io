/* This question has THREE  sub-questions. Please answer all of them. 
 * This question tests your understanding of when you need to allocate heap-memory and when you should free heap-memory.*/

#include<stdio.h>
#include<stdbool.h>
#include<stdlib.h>
/* Do not modify any line of code from here 
 * ****************************************/
#define NAME_LENGTH 80
typedef struct {
int ID;
char* firstname;
char* lastname;
}Student;
/***************to here********************/

int countNewLine(FILE * fptr) 
{
  int numline = 0;
  while (! feof(fptr)) {
      int onechar = fgetc(fptr);
      if (onechar == '\n') {
	  numline ++;
	}
    }
  return numline;
}

bool StudentRead(char *filename, Student **stu, int *numelem)
{
  FILE * fptr;
  fptr = fopen(filename, "r");
  if (fptr == NULL) {/* fopen fails*/
      return false;
    }
  int numline = countNewLine(fptr);
  
  int rtv; /*return value*/
  rtv = fseek(fptr, 0, SEEK_SET);
  if (rtv == -1) {/* fseek fails*/
      fclose (fptr);
      return false;
    }
  
  Student * stuptr = malloc(sizeof(* stuptr) * numline);
 
  if (stuptr == NULL) {/* malloc fails*/
      fclose (fptr);
      return false;
    }

  for (int ind = 0; ind < numline; ind ++) {
      /*Q2.B (12 points) hint: your answer goes here*/
      stuptr[ind].firstname=malloc(NAME_LENGTH);	
      stuptr[ind].lastname=malloc(NAME_LENGTH);	
      rtv = fscanf(fptr, "%d %s %s\n", &stuptr[ind].ID, stuptr[ind].firstname, stuptr[ind].lastname);
      if (rtv != 3) {/* fscanf fails*/
          for(int i=0;i<ind+1;i++)
	  {
		free(stuptr[i].firstname);
		free(stuptr[i].lastname);
          }
	  free(stuptr);
	  fclose (fptr);
	  return false;
	}
    }

  fclose (fptr);
  *numelem = numline;
  *stu = stuptr;
  return true;
}

void StudentPrint(Student * stu, int num)
{
  printf("There are %d students\n", num);
  for (int ind = 0; ind < num; ind ++)
    {
      printf("ID = %d, First Name = %s, Last Name = %s\n",
	     stu[ind].ID,  stu[ind].firstname, stu[ind].lastname);
    }
}

/* This program is called with a single command line argument. E.g. ./a.out testinput1.txt*/
/* It is supposed to: 1) read student records from the input file, 2) populate an array, and 3)Print the array. 
 * To read student records from the file, the main function calls the function StudentRead. 
 * StudentRead gets the number of lines in a file using the function countNewLine.  
 * The program has multiple bugs related to memory management:
 *
 ******************************************************************************************
 * Q2.A (4 points): Identify the functions that could leak memory.
 * Q2.B (12 points): Fix the StudentRead function to store student records into correct memory locations. You can assume first and lastnames have a maximum length of NAME_LENGTH chars.
 * Q2.C (24 points): Consider all possible leak scenarios and fix the memory leaks (24 points). Use valgrind (optional) to verify if you have fixed all the leaks. The valgrind command to use:
 * valgrind --tools=memcheck --leak-check=full q2 testinput1 
 * (here q2 is the name of the executable that you create. you can choose any name for the executable)*/
int main(int argc, char* argv[])
{
	if(argc != 2)
	{
		printf("You must run the program with the tstinput provided\n");
		return EXIT_FAILURE;
	}
	
  	Student * stu=NULL;
	int numelem=0;
	/*Q2.A (Identifying potential sources of memory leak - 4points): print the names of functions that leak memory. 
	(if there are multiple functions, print one function name per line). E.g. if function foo1,foo2, and foo3 leak memory then your
	answer should be: printf("foo1\n"); printf("foo2\n:); printf("foo3\n");*/
	printf("main\n");
	printf("StudentRead\n");
	
	if (StudentRead(argv[1], &stu, &numelem) == false) {
      		return EXIT_FAILURE;
    	}

	StudentPrint(stu,numelem);
	for(int i=0;i<numelem;i++)
	{
		free(stu[i].firstname);
		free(stu[i].lastname);
	}
	free(stu);
  	return EXIT_SUCCESS;
}
