/* This question has THREE  sub-questions. Please answer all of them. 
 * This question tests your understanding of hexadecimal notation, little-endian, and union types.*/

#include<stdio.h>
#define MAXLEN 4

/*Q3.A (5 points): create a union type named Answer, which has the following attributes:
*  ival - an integer
*  carr - a fixed-length array of characters with a maximum size of MAXLEN bytes 
*  please make sure the names are exactly the same. Assume that there is no padding (#pragma pack(1)).
*/
/*please type your answer here*/
typedef union {
int ival;
char carr[MAXLEN];
}Answer;

int main(int argc, char* argv[])
{
	/*Q3.B (2 points): Define a variable called ans whose data type is Answer
	type your answer here*/
	Answer ans;
	/*Q3.C (8 points): Initialize ival member if ans such that the program prints "ECE" when run. You will need the ASCII table.
	Assume that you are running the code on a little-endian machine and integers take 4 bytes of storage space.*/
	ans.ival=0x454345;/*type your answer here*/


	printf("%s\n",ans.carr); /*this statement should print ECE*/
} 

