#include<iostream>
#include<string>

enum Color{
	RED,
	BLUE,
	BLACK,
	WHITE
};

enum VehicleType{
	CAR,
	BUS
};

std::string colornames[]={"RED","BLUE","BLACK","WHITE"};

class Vehicle {
	public:
	       Color col;
       		Vehicle(){}	       
};

class Car:public Vehicle{
	public:
	Car(Color c) {col=c;std::cout<<"Creating "<<colornames[c]<<" Car"<<std::endl;}
};


class Bus:public Vehicle{
	public:
	Bus(Color c) {col=c;std::cout<<"Creating "<<colornames[c]<<" Bus"<<std::endl;}
};


Vehicle* VehicleFactory(VehicleType type, Color c) {
	if(type == BUS)
		return new Bus(c);
	else if(type == CAR)
		return new Car(c);
	else
		return NULL;
}

int main() {
	Vehicle* redCar = VehicleFactory(CAR,RED);
	Vehicle* blueBus = VehicleFactory(BUS,BLUE);
}
