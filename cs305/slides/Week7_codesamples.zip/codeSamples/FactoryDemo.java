import java.util.function.Function;
//Class::new refers to contructor
//by default methods are public

enum Color{
	RED,
	BLUE,
	BLACK,
	WHITE;
}

class Vehicle{
	Color col;
	Vehicle(){}
}


class Car extends Vehicle{
	Car(Color c) {col=c;System.out.println("Creating "+c+" Car");}
}

class Bus extends Vehicle{
	Bus(Color c) {col=c;System.out.println("Creating "+c+" Bus");}
}



enum VehicleFactory {
	CAR(Car::new),
	BUS(Bus::new);

	public final Function<Color, Vehicle> factoryHelper;

	VehicleFactory(Function<Color, Vehicle> helper) {
		this.factoryHelper = helper;
	}
}

class FactoryDemo{
	public static void main(String[] args) {
		Vehicle redCar = VehicleFactory.CAR.factoryHelper.apply(Color.RED);
		Vehicle blueBus = VehicleFactory.BUS.factoryHelper.apply(Color.BLUE);
	}
}
