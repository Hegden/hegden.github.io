import java.io.BufferedReader;
import java.io.IOException;
import java.io.FileReader;
import java.util.StringTokenizer;

interface CheckStrategy {
	public boolean Check(String s);
}

class All implements CheckStrategy {
	@Override
	public boolean Check(String s) {
		return true;
	}
}

class StartWithT implements CheckStrategy {
	@Override
	public boolean Check(String s) {
		if(s == null || s.length() == 0){
			return false;
		}
		return s.charAt(0) == 't';
	}
}

class LongerThan5 implements CheckStrategy {
	@Override
	public boolean Check(String s) {
		if(s == null)
			return false;
		return s.length() > 5;
	}
}

class Context {
	private CheckStrategy strategy;

	public Context() { 
		this.strategy = new All();
	}

	public void ChangeStrategy(CheckStrategy  strategy) {
		this.strategy = strategy;
	}

	public void filter(String filename) throws IOException {
		BufferedReader infile = new BufferedReader(new FileReader(filename));
		String buffer = null;
		while((buffer = infile.readLine()) != null) {
			StringTokenizer words = new StringTokenizer(buffer);
			while(words.hasMoreTokens()) {
				String word = words.nextToken();
				if(strategy.Check(word)) {
					System.out.println(word);
				}
			}
		}
	}
}


public class StrategyDemo {
	public static void main(String[] args) throws IOException {
		Context context = new Context();
		String filename = args[0];

		System.out.println("---Default Strategy: All---");
		context.filter(filename);

		System.out.println("\n---Change Strategy > 5---");
		context.ChangeStrategy(new LongerThan5());
		context.filter(filename);
	}	

}


