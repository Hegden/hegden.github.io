#include<iostream>
class Bank {
	private:
		static Bank* instance;
		Bank() {}
	public:
		static Bank* Create() {
			if(instance == NULL)
				instance = new Bank();
			return instance;
		}
		//..
};

Bank* Bank::instance=NULL;

int main() {
	Bank* bank1 = Bank::Create();
	std::cout<<"Memory location of instance (bank1): "<<bank1<<std::endl;
	Bank* bank2 = Bank::Create();
	std::cout<<"Memory location of instance (bank2): "<<bank2<<std::endl;
}



