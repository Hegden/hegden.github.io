class Bank{
	private String s;
	private static Bank instance = new Bank();
	private Bank() {s="hello world";}
	public static Bank Create() {
		return instance;
	}
	public void FlipCase() { s = s.toUpperCase();}
	public void PrintString() { System.out.println(s);}
}

public class singleton{
	
	public static void main(String[] args) {
	
	Bank bank1 = Bank.Create();
	
	bank1.FlipCase();
	bank1.PrintString();
	
	Bank bank2 = Bank.Create();
	bank2.PrintString();
	
	}
}
