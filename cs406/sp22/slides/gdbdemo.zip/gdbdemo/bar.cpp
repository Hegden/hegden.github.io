#include"bar.h"
float bar(int r, int s) {
	float h;
	h = 1.0 * (r + s);
	return h;
}


