#include<stdio.h>
#include"bar.h"

int foo(int a, int b) {
	int x = 0xABABABAB;
	int y = 0xCDCDCDCD;
	x=bar(x,y);
	return x*x;
}


int main(int argc, char* argv[]) {
	int ret = foo(10, 20); //compute expression
	printf("Value returned from foo: %d\n",ret); //print result
	return 0;
}
