#ifndef BAR_H
#define BAR_H

float bar(int r, int s);

#endif
